#!/bin/bash

echo "------------------------START Miner----------------------"
./algo -t cuda -a "NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88" -p nimiq.icemining.ca:2053 -n "My rig" --threads 10 
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
